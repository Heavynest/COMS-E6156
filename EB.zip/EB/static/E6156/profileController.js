//var app = angular.module("CustomerApp", []);

CustomerApp.controller("profileController", function($scope, $http, $location, $window) {

    console.log("Profile controller loaded.")

    var s3 = jQuery.LiveAddress({
        key: "18981749384552786",
        waitForStreet: true,
        debug: true,
        target: "US",
        placeholder: "Enter address",
        addresses: [{
            freeform: '#newaddress'
        }]
    });

    s3.on("AddressAccepted", function(event, data, previousHandler)
    {
        console.log("Boo Yah!")
        console.log(JSON.stringify(data.response, null,3))

    });

    $scope.placeholder = "enter an address and select a choice.";
    // $scope.address="hh"
    $scope.addressKinds = ['Home', 'Work', 'Mobile','Other'];
    $scope.akind="Subtype"
    $scope.telekind="Subtype"
    $scope.emailkind="Subtype"
    $scope.otherkind="Subtype"



    $scope.addressKind = function(idx) {
        console.log("Address kknk = " + $scope.addressKinds[idx]);
        $scope.akind=$scope.addressKinds[idx];
        console.log("Address = " + $scope.address);
    };

    $scope.teleKind = function(idx) {
        console.log("Address kknk = " + $scope.addressKinds[idx]);
        $scope.telekind=$scope.addressKinds[idx];
        console.log("Address = " + $scope.address);
    };

    $scope.emailKind = function(idx) {
        console.log("Address kknk = " + $scope.addressKinds[idx]);
        $scope.emailkind=$scope.addressKinds[idx];
        console.log("Address = " + $scope.address);
    };
    $scope.otherKind = function(idx) {
        console.log("Address kknk = " + $scope.addressKinds[idx]);
        $scope.otherkind=$scope.addressKinds[idx];
        console.log("Address = " + $scope.address);
    };

    baseUrl = "http://127.0.0.1:5033/api";

    $scope.updateAdress=function() {update("ADDRESS",$scope.akind,$scope.address)};
    $scope.updateTelephone=function(){update("TELEPHONE",$scope.telekind,$scope.telephone)};
    $scope.updateEmail=function(){update("EMAIL",$scope.emailkind,$scope.email)};
    $scope.updateOther=function(){update("OTHER",$scope.otherkind,$scope.other)};

     function update(e_type,e_subtype,e_value){
        var body={"element_type":e_type,"element_subtype":e_subtype,"element_value":e_value};

        sStorage= $window.sessionStorage;
        var req={
            method:"POST",
            url:baseUrl+"/profile",
            headers:{'Authorization':sStorage.getItem("token")},
            data:body
        };
        $http(req
        ).success(
            function (data, status, headers) {
                // var rsp = data;
                // var h = headers();
                // var result = data.data;
                // console.log("Data = " + JSON.stringify(result, null, 4));
                // console.log("Headers = " + JSON.stringify(h, null, 4))
                // console.log("RSP = " + JSON.stringify(rsp, null, 4))
                //
                // var auth = h.authorization;
                // sStorage.setItem("token", auth);
                console.log("Cool")
                resolve("OK")
            }).error(function (error) {
                console.log("Error = " + JSON.stringify(error, null, 4));
                reject("Error")
            });
    }

});

